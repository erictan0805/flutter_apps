import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
//Sets up the main application with a title, theme, and the initial screen (ToDoListScreen).
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'To-Do List',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ToDoListScreen(),
    );
  }
}

class ToDoListScreen extends StatefulWidget {
//A stateful widget that manages the state of the to-do list.
  @override
  _ToDoListScreenState createState() => _ToDoListScreenState();
}

class _ToDoListScreenState extends State<ToDoListScreen> {
  List<Map<String, String>> _tasks = [];
  List<Map<String, String>> _deletedTasks = [];
  final TextEditingController _taskController = TextEditingController();
  //_taskController: Controller for the text field where users enter new tasks.
  String _selectedDate = '';
  int _goal = 0;
  int _completedTasksToday = 0;
  int _completedTasksWeekly = 0;

  @override
  void initState() {
  //initState(): Initializes the state by loading saved data and calculating progress.

    super.initState();
    _loadTasks();
    _loadDeletedTasks();
    _loadGoal();
    _loadCompletedTasks();
    _calculateWeeklyProgress();
  }

  Future<void> _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasks = prefs.getStringList('tasks') ?? [];
    setState(() {
      _tasks = tasks.map((task) {
        final parts = task.split('|');
        return {'task': parts[0], 'date': parts.length > 1 ? parts[1] : '', 'completed_date': parts.length > 2 ? parts[2] : ''};
      }).toList();
    });
  }

  Future<void> _loadDeletedTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final deletedTasks = prefs.getStringList('deleted_tasks') ?? [];
    setState(() {
      _deletedTasks = deletedTasks.map((task) {
        final parts = task.split('|');
        return {'task': parts[0], 'date': parts.length > 1 ? parts[1] : '', 'completed_date': parts.length > 2 ? parts[2] : ''};
      }).toList();
    });
  }

  Future<void> _saveTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tasks = _tasks.map((task) => '${task['task']}|${task['date']}|${task['completed_date']}').toList();
    prefs.setStringList('tasks', tasks);
  }

  Future<void> _saveDeletedTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final deletedTasks = _deletedTasks.map((task) => '${task['task']}|${task['date']}|${task['completed_date']}').toList();
    prefs.setStringList('deleted_tasks', deletedTasks);
  }

  Future<void> _loadGoal() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _goal = prefs.getInt('goal') ?? 0;
    });
  }

  Future<void> _saveGoal(int goal) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt('goal', goal);
  }

  Future<void> _loadCompletedTasks() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _completedTasksToday = prefs.getInt('completed_tasks_today') ?? 0;
      _completedTasksWeekly = prefs.getInt('completed_tasks_weekly') ?? 0;
    });
  }

  Future<void> _saveCompletedTasks() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt('completed_tasks_today', _completedTasksToday);
    prefs.setInt('completed_tasks_weekly', _completedTasksWeekly);
  }

  void _addTask() async {
    if (_taskController.text.isNotEmpty) {
      final now = DateTime.now();
      final date = _selectedDate.isNotEmpty ? _selectedDate : '${now.year}-${now.month}-${now.day}';
      setState(() {
        _tasks.add({'task': _taskController.text, 'date': date, 'completed_date': ''});
        _taskController.clear();
        _selectedDate = '';
        _saveTasks();
      });
    }
  }

  void _removeTask(int index) {
    setState(() {
      _deletedTasks.add(_tasks[index]);
      _tasks.removeAt(index);
      _saveTasks();
      _saveDeletedTasks();
    });
  }

  void _restoreTask(int index) {
    setState(() {
      _tasks.add(_deletedTasks[index]);
      _deletedTasks.removeAt(index);
      _saveTasks();
      _saveDeletedTasks();
    });
  }

  void _toggleTaskCompletion(int index) {
  //_toggleTaskCompletion(int index): Toggles the completion status of a task and updates the counts of completed tasks.

    setState(() {
      final task = _tasks[index];
      final isCompleted = task['completed_date']!.isNotEmpty;
      final now = DateTime.now();
      final today = DateFormat('yyyy-MM-dd').format(now);

      if (isCompleted) {
        _completedTasksToday--;
        _completedTasksWeekly--; 
        _tasks[index]['completed_date'] = '';
      } else {
        _completedTasksToday++;
        _completedTasksWeekly++;
        _tasks[index]['completed_date'] = today;
      }
      
      _saveTasks();
      _saveCompletedTasks();
      _calculateWeeklyProgress();
    });
  }

  void _calculateWeeklyProgress() {
  //Calculates the number of tasks completed during the current week and updates the weekly progress.
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final endOfWeek = startOfWeek.add(Duration(days: 6));
    
    int weeklyCount = 0;
    
    for (var task in _tasks) {
      final completedDateStr = task['completed_date']!;
      if (completedDateStr.isNotEmpty) {
        final completedDate = DateTime.parse(completedDateStr);
        if (completedDate.isAfter(startOfWeek) && completedDate.isBefore(endOfWeek.add(Duration(days: 1)))) {
          weeklyCount++;
        }
      }
    }

    setState(() {
      _completedTasksWeekly = weeklyCount;
    });

    _saveCompletedTasks();
  }

  Future<void> _selectDate() async {
    final now = DateTime.now();
    final selectedDate = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 10),
    );

    if (selectedDate != null) {
      setState(() {
        _selectedDate = '${selectedDate.year}-${selectedDate.month}-${selectedDate.day}';
      });
    }
  }

  void _showGoalDialog() {
  //_showGoalDialog(): Opens a dialog to set or update the daily goal.
    showDialog(
      context: context,
      builder: (context) {
        final controller = TextEditingController();
        return AlertDialog(
          title: Text('Set Daily Goal'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Enter goal number'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                final goal = int.tryParse(controller.text);
                if (goal != null) {
                  setState(() {
                    _goal = goal;
                    _saveGoal(goal);
                  });
                }
                Navigator.of(context).pop();
              },
              child: Text('Set'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final progressToday = _goal > 0 ? (_completedTasksToday / _goal * 100).toStringAsFixed(1) : '0.0';

    return Scaffold(
    //Scaffold: Provides the structure for the screen, including an AppBar, Drawer, and main body.

      appBar: AppBar(
        title: Text('To-Do List'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'To-Do App',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: Text('Set Daily Goal'),
              onTap: _showGoalDialog,
            ),
            ListTile(
              title: Text('Weekly Progress'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WeeklyProgressScreen(
                      completedTasksWeekly: _completedTasksWeekly,
                      totalTasks: _tasks.length,
                    ),
                  ),
                );
              },
            ),
            ListTile(
              title: Text('Task History'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TaskHistoryScreen(
                      deletedTasks: _deletedTasks,
                      onRestore: _restoreTask,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _taskController,
              decoration: InputDecoration(
                labelText: 'Enter a new task',
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: _addTask,
                ),
              ),
              onSubmitted: (_) => _addTask(),
            ),
            SizedBox(height: 8.0),
            ElevatedButton(
            //ElevatedButton: For selecting a date.

              onPressed: _selectDate,
              child: Text(_selectedDate.isEmpty ? 'Select Date' : 'Selected Date: $_selectedDate'),
            ),
            SizedBox(height: 16.0),
            if (_goal > 0)
              Text(
                'Daily Goal: $_goal tasks\nCompleted Today: $_completedTasksToday tasks\nProgress: $progressToday%',
                style: TextStyle(fontSize: 16),
              ),
            SizedBox(height: 16.0),
            Expanded(
              child: ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, index) {
                  final task = _tasks[index];
                  final isCompleted = task['completed_date']!.isNotEmpty;
                  final taskText = isCompleted ? task['task']! + ' (Completed)' : task['task']!;
                  final taskDate = task['date']!;
                  final completionDate = task['completed_date']!;

                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8.0),
                    elevation: 5,
                    child: ListTile(
                      leading: Icon(
                        isCompleted ? Icons.check_box : Icons.check_box_outline_blank,
                        color: isCompleted ? Colors.green : Colors.grey,
                      ),
                      title: Text(
                        '$taskText (Due: $taskDate)',
                        style: TextStyle(
                          decoration: isCompleted ? TextDecoration.lineThrough : null,
                        ),
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _removeTask(index),
                      ),
                      onTap: () => _toggleTaskCompletion(index),
                    ),
                  );
                },
              ),
            ),
            if (_goal > 0 && _completedTasksToday >= _goal)
            //Displays a congratulatory message if the daily goal is met.
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'Congratulations! You have reached your daily goal!',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class TaskHistoryScreen extends StatelessWidget {
  final List<Map<String, String>> deletedTasks;
  final Function(int) onRestore;

  TaskHistoryScreen({required this.deletedTasks, required this.onRestore});
  //TaskHistoryScreen: Displays a list of deleted tasks with an option to restore them.

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task History'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: deletedTasks.length,
          itemBuilder: (context, index) {
            final task = deletedTasks[index];
            final taskText = task['task']!;
            final taskDate = task['date']!;

            return Card(
              margin: EdgeInsets.symmetric(vertical: 8.0),
              elevation: 5,
              child: ListTile(
                title: Text('$taskText (Due: $taskDate)'),
                trailing: IconButton(
                  icon: Icon(Icons.restore, color: Colors.blue),
                  onPressed: () => onRestore(index),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class WeeklyProgressScreen extends StatelessWidget {
  final int completedTasksWeekly;
  final int totalTasks;
//WeeklyProgressScreen: Shows the total tasks created and completed for the current week.
  WeeklyProgressScreen({required this.completedTasksWeekly, required this.totalTasks});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final endOfWeek = startOfWeek.add(const Duration(days: 6));

    return Scaffold(
      appBar: AppBar(
        title: Text('Weekly Progress'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Weekly Progress',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.0),
            Text(
              'Total Tasks Created This Week: $totalTasks',
              style: TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
            Text(
              'Tasks Completed This Week: $completedTasksWeekly',
              style: TextStyle(fontSize: 18),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
