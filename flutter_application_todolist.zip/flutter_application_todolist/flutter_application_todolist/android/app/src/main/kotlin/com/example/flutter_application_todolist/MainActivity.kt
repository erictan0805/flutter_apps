package com.example.flutter_application_todolist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
