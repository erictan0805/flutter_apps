import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: BMIPage(),
    );
  }
}

class BMIPage extends StatefulWidget {
//To create a page that can change and update its content based on user input.
  @override
  _BMIPageState createState() => _BMIPageState();
}

class _BMIPageState extends State<BMIPage> {
//To manage and store user inputs and the results of the BMI calculation.

  final _formKey = GlobalKey<FormState>();
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  String _bmiResult = '';
  String _category = '';

  void _calculateBMI() {
  //To perform the BMI calculation and update the results on the screen.

    if (_formKey.currentState!.validate()) {
      final height = double.tryParse(_heightController.text);
      final weight = double.tryParse(_weightController.text);

      if (height != null && weight != null && height > 0) {
        final bmi = weight / (height * height);
        String category;

        if (bmi < 16) {
          category = 'Severe Thinness';
        } else if (bmi >= 16 && bmi < 17) {
          category = 'Moderate Thinness';
        } else if (bmi >= 17 && bmi < 18.5) {
          category = 'Mild Thinness';
        } else if (bmi >= 18.5 && bmi < 25) {
          category = 'Normal';
        } else if (bmi >= 25 && bmi < 30) {
          category = 'Overweight';
        } else if (bmi >= 30 && bmi < 35) {
          category = 'Obese Class I';
        } else if (bmi >= 35 && bmi < 40) {
          category = 'Obese Class II';
        } else {
          category = 'Obese Class III';
        }

        setState(() {
          _bmiResult = 'Your BMI is ${bmi.toStringAsFixed(2)}';
          _category = 'Category: $category';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
  //To create the visual layout of the BMI calculator app and handle user input.
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              TextFormField(
                controller: _heightController,
                decoration: InputDecoration(labelText: 'Height (m)'),
                keyboardType: TextInputType.numberWithOptions(decimal: true),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your height';
                  }
                  final height = double.tryParse(value);
                  if (height == null || height <= 0) {
                    return 'Please enter a valid height';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _weightController,
                decoration: InputDecoration(labelText: 'Weight (kg)'),
                keyboardType: TextInputType.numberWithOptions(decimal: true),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your weight';
                  }
                  final weight = double.tryParse(value);
                  if (weight == null || weight <= 0) {
                    return 'Please enter a valid weight';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _calculateBMI,
                child: Text('Calculate BMI'),
              ),
              SizedBox(height: 20),
              Text(
                _bmiResult,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                _category,
                style: TextStyle(fontSize: 20, color: Colors.blueAccent),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
