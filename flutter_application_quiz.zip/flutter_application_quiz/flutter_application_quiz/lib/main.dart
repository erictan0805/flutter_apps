import 'package:flutter/material.dart';

void main() {
  runApp(QuizApp());
}
//Every Flutter app needs a main() function to start running. runApp initializes the app with QuizApp.

class QuizApp extends StatelessWidget {

//QuizApp is the root widget of the application. It sets up the theme (look and feel) of the app and decides what the first screen of the app will be.
//This is the main setup for the app, defining its theme and the first page users see when they open the app.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Futuristic Quiz App',
      theme: ThemeData(
        useMaterial3: true, 
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          primary: Colors.blueAccent,
          secondary: Colors.teal,
        ),
        scaffoldBackgroundColor: Colors.blueGrey[50],
        textTheme: TextTheme(
          bodyLarge: TextStyle(fontSize: 20.0, color: Colors.black87, fontFamily: 'Roboto'),
          titleLarge: TextStyle(fontSize: 28.0, fontWeight: FontWeight.bold, fontFamily: 'Roboto'),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.blueAccent,
            padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
            textStyle: TextStyle(fontSize: 18.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
          ),
        ),
        cardTheme: CardTheme(
          elevation: 8.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          color: Colors.white,
          shadowColor: Colors.black.withOpacity(0.1),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16.0),
            borderSide: BorderSide(color: Colors.blueAccent),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueAccent, width: 2.0),
            borderRadius: BorderRadius.circular(16.0),
          ),
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: Colors.blueAccent),
        ),
      ),
      home: UserNamePage(),
    );
  }
}


class UserNamePage extends StatefulWidget {
  @override
  _UserNamePageState createState() => _UserNamePageState();
}

class _UserNamePageState extends State<UserNamePage> {
  final TextEditingController _nameController = TextEditingController();

  void _startQuiz() {
    final name = _nameController.text;
    if (name.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => QuizHomePage(userName: name),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter your name')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Enter Your Name'),
        backgroundColor: Colors.blueAccent,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[200]!, Colors.blue[400]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'Enter your name',
                  ),
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                SizedBox(height: 30.0),
                ElevatedButton(
                  onPressed: _startQuiz,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.play_arrow, size: 24.0),
                      SizedBox(width: 15.0),
                      Text('Start Quiz'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class QuizHomePage extends StatefulWidget {
  final String userName;

  QuizHomePage({required this.userName});

  @override
  _QuizHomePageState createState() => _QuizHomePageState();
}

class _QuizHomePageState extends State<QuizHomePage> {
  final List<Question> _questions = [
    Question('Ali ___ a good boy.', ['are', 'is', 'am', 'was'], 'is'),
    Question('Ramanan ____ go to school practice tomorrow.', ['was', 'were', 'are', 'will'], 'will'),
    Question('1 + 1 x 4 = ???', ['1', '5', '2', '6'], '5'),
    Question('Which country is not inside Malaysia?', ['Beijing', 'Sarawak', 'Penang', 'Selangor'], 'Beijing'),
    Question('Alex is a ____ boy because he is always mischievous.', ['naughty', 'clever', 'obedient', 'good'], 'naughty'),
    Question('Solve for x: 2x + 3 = 11', ['4', '5', '6', '7'], '4'),
    Question('How many milliliters are in a liter?', ['1ML', '2000ML', '500ML', '1000ML'], '1000ML'),
    Question('If pen + apple = ?', ['watermelon', 'Banana', 'Apple Pen', 'Tomato pen'], 'Apple Pen'),
    Question('How many colours are there in a rainbow?', ['4', '5', '6', '7'], '7'),
    Question('Who is known for hits like “Shake It Off”?', ['Taylor Swift', 'Justin Bieber', 'Alan Walker', 'Marshmello'], 'Taylor Swift'),
  ];
  //Quiz questions

  int _currentQuestionIndex = 0;
  List<String?> _selectedAnswers = List.filled(10, null);
  List<bool> _answerCorrectness = List.filled(10, false);
  bool _quizFinished = false;
  int _score = 0;
  //These variables are used to manage the quiz's state, such as keeping track of the current question, the user's answers, correctness of answers, and the score.

  void _selectAnswer(String selectedAnswer) {
    final currentQuestion = _questions[_currentQuestionIndex];

    setState(() {
      if (_selectedAnswers[_currentQuestionIndex] != null) {
        
        if (_selectedAnswers[_currentQuestionIndex] == currentQuestion.correctAnswer) {
          _score--; 
        }
      }
//To handle answer selection, update the user's score, and move to the next question or end the quiz.

    
      _selectedAnswers[_currentQuestionIndex] = selectedAnswer;
      if (selectedAnswer == currentQuestion.correctAnswer) {
        _answerCorrectness[_currentQuestionIndex] = true;
        _score++; 
      } else {
        _answerCorrectness[_currentQuestionIndex] = false;
      }

      
      if (_currentQuestionIndex < _questions.length - 1) {
        _currentQuestionIndex++;
      } else {
        _quizFinished = true;
      }
    });
  }
//Triggers the score update after every answer from user

  void _confirmSubmit() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Confirm Submission'),
        content: Text('Are you sure you want to submit?'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); 
            },
            child: Text('No'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); 
              _submitQuiz(); 
            },
            child: Text('Yes'),
          ),
        ],
      ),
    );
  }
//To give users a chance to review their answers before final submission.

  void _submitQuiz() {
    setState(() {
      _quizFinished = true;
    });
  }
//To handle the completion of the quiz and show the results to the user.

  void _tryAgain() {
    setState(() {
      _currentQuestionIndex = 0;
      _selectedAnswers = List.filled(10, null);
      _answerCorrectness = List.filled(10, false);
      _quizFinished = false;
      _score = 0;
    });
  }
//To allow users to retake the quiz from the beginning after seeing their results.

  @override
  Widget build(BuildContext context) {
    if (_quizFinished) {
      final isCongratulations = _score > 5; 
      return Scaffold(
        appBar: AppBar(
          title: Text('Quiz Results'),
          backgroundColor: Colors.blueAccent,
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue[100]!, Colors.blue[300]!],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Results of ${widget.userName}!',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.blueAccent),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10.0),
                Text(
                  isCongratulations ? 'Great job!' : 'You need improvement.',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: isCongratulations ? Colors.green : Colors.red,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20.0),
                Text(
                  'Your score: $_score/${_questions.length}',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.blueAccent),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 30.0),
                Expanded(
                  child: ListView.builder(
                    itemCount: _questions.length,
                    itemBuilder: (context, index) {
                      final question = _questions[index];
                      final selectedAnswer = _selectedAnswers[index];
                      final isCorrect = _answerCorrectness[index];
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 8.0),
                        child: ListTile(
                          title: Text(question.questionText),
                          subtitle: Text(
                            'Selected: ${selectedAnswer ?? "None"}\nCorrect Answer: ${question.correctAnswer}',
                            style: TextStyle(color: isCorrect ? Colors.green : Colors.red),
                          ),
                          contentPadding: EdgeInsets.all(16.0),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 30.0),
                ElevatedButton(
                  onPressed: _tryAgain,
                  child: Text('Try Again'),
                ),
              ],
            ),
          ),
        ),
      );
    }
  //Displaying all the result information of user after the quiz has ended

    final question = _questions[_currentQuestionIndex];
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz App'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[100]!, Colors.blue[300]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                question.questionText,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              SizedBox(height: 20.0),
              ...question.answers.map((answer) {
                final isSelected = _selectedAnswers[_currentQuestionIndex] == answer;
                final isCorrect = answer == question.correctAnswer;
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 8.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _quizFinished
                          ? (isSelected
                              ? (isCorrect ? Colors.green : Colors.red)
                              : Colors.grey)
                          : Colors.blueAccent,
                    ),
                    onPressed: _quizFinished ? null : () => _selectAnswer(answer),
                    child: Text(answer),
                  ),
                );
              }).toList(),
              SizedBox(height: 20.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_currentQuestionIndex > 0)
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _currentQuestionIndex--;
                        });
                      },
                      child: Text('Back'),
                    ),
                  if (_currentQuestionIndex < _questions.length - 1)
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _currentQuestionIndex++;
                        });
                      },
                      child: Text('Next'),
                    ),
                  if (_currentQuestionIndex == _questions.length - 1)
                    ElevatedButton(
                      onPressed: _confirmSubmit,
                      child: Text('Submit'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
//build(BuildContext context): This function decides what to display on the screen based on the quiz's state.
//If the quiz is finished: Shows the results page with your score and whether you did well or need improvement. It also lets you review your answers and try again.
//If the quiz is ongoing: Displays the current question, answer choices, and navigation buttons (Back, Next, Submit).
class Question {
  final String questionText;
  final List<String> answers;
  final String correctAnswer;

  Question(this.questionText, this.answers, this.correctAnswer);
}

