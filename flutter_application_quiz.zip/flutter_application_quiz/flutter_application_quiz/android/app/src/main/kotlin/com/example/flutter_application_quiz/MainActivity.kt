package com.example.flutter_application_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
