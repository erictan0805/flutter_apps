import 'package:flutter/material.dart';
import 'models/recipe.dart';

class RecipeDetailPage extends StatelessWidget {
  final Recipe recipe;

  RecipeDetailPage({required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recipe.title),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: <Widget>[
          SizedBox(height: 16),
          Text(
            'Ingredients:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          ...recipe.ingredients.map((ingredient) => Text('★ $ingredient')).toList(),  //This line generates a list of Text widgets for each ingredient in the recipe. The map function applies a transformation to each ingredient, adding a bullet (★) before each item, and toList() converts the iterable to a list.
          SizedBox(height: 16),
          Text(
            'Instructions:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          ...recipe.instructions.map((step) => Text('★ $step')).toList(),  //This line generates a list of Text widgets for each step in the recipe's instructions, with each step prefixed by a bullet (★).
        ],
      ),
    );
  }
}
