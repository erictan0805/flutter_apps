import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

enum AudioSourceOption { Network, Asset }
enum RepeatMode { none, one, all } //_repeatMode: Manages the repeat mode.

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final AudioPlayer _player = AudioPlayer();
  String _currentSongTitle = "";
  String _currentSongArtUrl = "";
  RepeatMode _repeatMode = RepeatMode.none;

  final List<Song> _songs = [
    Song(
      title: "Calm Sea Sound",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      artUrl: "/Users/shadymok/Downloads/ocean-1867285_640.jpg",
    ),
    Song(
      title: "Forest Ambience",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
      artUrl: "/Users/shadymok/Downloads/forest.jpeg",
    ),
    Song(
      title: "Rain Sound",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
      artUrl: "/Users/shadymok/Downloads/6rpKpP9z-gettyimages-1257951336.jpg",
    ),
    Song(
      title: "Ocean Waves",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
      artUrl: "/Users/shadymok/Downloads/waves.jpeg",
    ),
    Song(
      title: "Birds Chirping",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
      artUrl: "/Users/shadymok/Downloads/birds.jpeg",
    ),
  ];

  @override
  void initState() { //initState: Initializes the state. Sets up the audio player with the first song if the list is not empty.
    super.initState();
    WidgetsFlutterBinding.ensureInitialized();
    if (_songs.isNotEmpty) {
      _setupAudioPlayer(_songs[0]);//_setupAudioPlayer: Configures the audio player with the provided song. Sets the audio source and loop mode based on the RepeatMode.
    }
  }

  @override
  Widget build(BuildContext context) { //build: Constructs the UI of the HomePage using a Scaffold, including an app bar, a gradient background, song art, title, progress bar, and control buttons.
    return Scaffold(
      appBar: AppBar(
        title: const Text("Audio Player"),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepPurple.shade700, Colors.blueAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _songArt(), //_songArt: Displays the current song's art using an AnimatedContainer. If no art URL is provided, it shows a default music note icon.
                const SizedBox(height: 20),
                _songTitleWidget(), //_songTitleWidget: Shows the title of the current song with an animation effect when it changes.
                const SizedBox(height: 20),
                Expanded(child: _songList()), //_songList: Displays a list of songs. Each item shows the song's art and title. Tapping an item sets up the audio player with the selected song.
                const SizedBox(height: 20),
                _progressBar(), //_progressBar: Displays a progress bar that updates as the song plays. Allows seeking within the song.
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _controlButtons(),
                    const SizedBox(width: 20),
                    _playbackControlButton(), //_playbackControlButton: Provides play, pause, or replay buttons based on the current playback state.
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _setupAudioPlayer(Song song) async {
    try {
      setState(() {
        _currentSongTitle = song.title;
        _currentSongArtUrl = song.artUrl;
      });

      if (song.url.startsWith("http")) {
        await _player.setAudioSource(AudioSource.uri(Uri.parse(song.url)));
      } else {
        await _player.setAudioSource(AudioSource.asset(song.url));
      }

      _player.setLoopMode(_repeatMode == RepeatMode.none
          ? LoopMode.off
          : _repeatMode == RepeatMode.one
              ? LoopMode.one
              : LoopMode.all);
    } catch (e) {
      print("Error loading audio source: $e");
    }
  }

  Widget _songArt() {
    return _currentSongArtUrl.isNotEmpty
        ? AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeInOut,
            width: 250,
            height: 250,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
              image: DecorationImage(
                image: AssetImage(_currentSongArtUrl),
                fit: BoxFit.cover,
              ),
            ),
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.transparent,
              ),
            ),
          )
        : const Icon(
            Icons.music_note,
            size: 250,
            color: Colors.grey,
          );
  }

  Widget _songTitleWidget() {
    return AnimatedDefaultTextStyle(
      duration: const Duration(milliseconds: 300),
      style: const TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
      child: Text(
        _currentSongTitle,
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _progressBar() {
    return StreamBuilder<Duration?>(
      stream: _player.positionStream,
      builder: (context, snapshot) {
        return ProgressBar(
          progress: snapshot.data ?? Duration.zero,
          buffered: _player.bufferedPosition,
          total: _player.duration ?? Duration.zero,
          onSeek: (duration) {
            _player.seek(duration);
          },
          barHeight: 6.0,
          thumbColor: Colors.white,
          baseBarColor: Colors.white.withOpacity(0.3),
          bufferedBarColor: Colors.white.withOpacity(0.5),
          progressBarColor: Colors.deepPurpleAccent,
        );
      },
    );
  }

  Widget _playbackControlButton() {
    return StreamBuilder<PlayerState>(
      stream: _player.playerStateStream,
      builder: (context, snapshot) {
        final processingState = snapshot.data?.processingState;
        final playing = snapshot.data?.playing;

        if (processingState == ProcessingState.loading ||
            processingState == ProcessingState.buffering) {
          return const SizedBox(
            width: 64,
            height: 64,
            child: CircularProgressIndicator(
              color: Colors.white,
            ),
          );
        } else if (playing != true) {
          return IconButton(
            icon: const Icon(Icons.play_arrow),
            iconSize: 64,
            color: Colors.white,
            onPressed: _player.play,
          );
        } else if (processingState != ProcessingState.completed) {
          return IconButton(
            icon: const Icon(Icons.pause),
            iconSize: 64,
            color: Colors.white,
            onPressed: _player.pause,
          );
        } else {
          return IconButton(
            icon: const Icon(Icons.replay),
            iconSize: 64,
            color: Colors.white,
            onPressed: () => _player.seek(Duration.zero),
          );
        }
      },
    );
  }

  Widget _controlButtons() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            IconButton(
              icon: Icon(
                _repeatMode == RepeatMode.none
                    ? Icons.repeat
                    : _repeatMode == RepeatMode.one
                        ? Icons.repeat_one
                        : Icons.repeat,
                color: Colors.white,
              ),
              onPressed: _toggleRepeatMode, //_toggleRepeatMode: Cycles through repeat modes and updates the player's loop mode.
            ),
            IconButton(
              icon: const Icon(
                Icons.replay,
                color: Colors.white,
              ),
              onPressed: _repeatCurrentSong, //_repeatCurrentSong: Seeks to the beginning of the song and starts playing it.

            ),
            const Icon(
              Icons.speed,
              color: Colors.white,
            ),
            StreamBuilder<double>(
              stream: _player.speedStream,
              builder: (context, snapshot) {
                return Slider(
                  min: 0.5,
                  max: 3.0,
                  value: snapshot.data ?? 1.0,
                  divisions: 5,
                  activeColor: Colors.white,
                  inactiveColor: Colors.white.withOpacity(0.5),
                  onChanged: (value) async {
                    await _player.setSpeed(value);
                  },
                );
              },
            ),
          ],
        ),
        StreamBuilder<double>(
          stream: _player.volumeStream,
          builder: (context, snapshot) {
            return Row(
              children: [
                const Icon(
                  Icons.volume_up,
                  color: Colors.white,
                ),
                Slider(
                  min: 0.0,
                  max: 1.0,
                  value: snapshot.data ?? 1.0,
                  divisions: 10,
                  activeColor: Colors.white,
                  inactiveColor: Colors.white.withOpacity(0.5),
                  onChanged: (value) async {
                    await _player.setVolume(value);
                  },
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  void _toggleRepeatMode() {
    setState(() {
      _repeatMode = RepeatMode.values[(_repeatMode.index + 1) % RepeatMode.values.length];
      _player.setLoopMode(
        _repeatMode == RepeatMode.none
            ? LoopMode.off
            : _repeatMode == RepeatMode.one
                ? LoopMode.one
                : LoopMode.all,
      );
    });
  }

  void _repeatCurrentSong() {
    _player.seek(Duration.zero);
    _player.play();
  }

  Widget _songList() {
    return ListView.builder(
      itemCount: _songs.length,
      itemBuilder: (context, index) {
        final song = _songs[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: AssetImage(song.artUrl),
          ),
          title: Text(
            song.title,
            style: const TextStyle(color: Colors.white),
          ),
          onTap: () => _setupAudioPlayer(song),
        );
      },
    );
  }
}

class Song { //Song Class: A simple way to organize information about each song, like its title, where to find it, and its cover art.
  final String title;
  final String url;
  final String artUrl;

  Song({ 
    required this.title,
    required this.url,
    required this.artUrl,
  });
}
