package com.example.audio_player_flutter_yt_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
